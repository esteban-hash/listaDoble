/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listasdobles;

/**
 *
 * @author Esteban Lopez
 */
import java.util.Scanner;
public class ListasDobles {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     ListaDoble LD = new ListaDoble();
        int op = 0;
        char r = 0;
        int c = 0;
        Scanner s = new Scanner(System.in);
        do {
            System.out.println("-------------Opciones-------------"); //menu
            System.out.println("1.- Insertar elemento en lista");
            System.out.println("2.- Mostrar lista completa");
            System.out.println("3.- Eliminar un elemento");
            System.out.println("3.- Salir");
            op = s.nextInt();
            switch (op) {
                case 1:

                    int opc = 0;
                    System.out.println("¿Donde desea ingresar datos?"); // se pide donde quiere ingresar
                    System.out.println("1.- Inicio || 2.-Final");
                    opc = s.nextInt();
                    if (opc == 1) { // si el usuario dijo que quierie agregar al inicio
                        do {
                            System.out.println("Ingresa el elemento ");//ingresa elemento
                            LD.Inicio(c = s.nextInt());
                            System.out.println("Desea ingresar otro dato?"); //pregunta si quiere ingresar mas o no
                            System.out.println("s= Si || n= No");
                            r = s.next().charAt(0);
                        } while (r == 's'); //termina el proceso

                    } else if (opc == 2) { //ingresar elemento al final
                        do {
                            System.out.println("Ingresa el elemento ");
                            LD.Fin(c = s.nextInt());
                            System.out.println("Desea ingresar otro dato?");
                            System.out.println("s= Si || n= No");
                            r = s.next().charAt(0);
                        } while (r == 's'); //si dice que no el proceso termina
                    } else if (op > 2) {
                        System.out.println("Error");
                    }

                    break;
                case 2: //visualizacion de la lista
                    int O = 0;
                    System.out.println("¿Como Quiere Visualizar La Lista?");
                    System.out.println("1.- Inicio - Final || 2.-Final - Inicio ");
                    O = s.nextInt();
                    if (O == 1) {
                        if (LD.Vacia()) { // verifica si esta vacia la lista o no
                            System.out.println("Sin elementos, lista vacia"); //si esta vacia manda ese mensaje
                        } else { //si no esta vacia, muestra la lista de inicio a fin
                            LD.MostarI();
                        }

                    } else if (op == 2) { // verifica si esta vacia la lista o no
                        if (LD.Vacia()) { 
                            System.out.println("Sin elementos, lista vacia"); //si esta vacia muestra ese mensaje
                        } else { //sino muestra la lista de fin a inicio
                            LD.MostarF();
                        }

                    } else if (op > 2) {
                        System.out.println("Opcion no valida!!!");
                    }

                    break;
                case 3:
                    int opcion = 0;
                    System.out.println("¿Como Quiere Eliminar El Dato?");
                    System.out.println("1.- Inicio || 2.-Final || 3.- Especifico ");
                    opcion = s.nextInt();
                    if (opcion == 1) {
                        if (LD.Vacia()) { //verifica si la lista esta vacia o no
                            System.out.println("Sin elementos"); //si esta vacia dice que no tiene elementos
                        } else {
                            System.out.println("El Elemento Eliminado Es: " + LD.eliminarI()); //si tiene elementos elimina el primer elemento
                            System.out.println("Lista de Inicio A Fin Con El Elemento Eliminado");
                            LD.MostarI(); //muestra la lista con los elementos eliminados
                            System.out.println("Lista de Fin A Inicio Con El Elemento Eliminado");
                            LD.MostarF();
                        }

                    } else if (opcion == 2) {
                        if (LD.Vacia()) { //verifica si la lista esta vacia o no
                            System.out.println("Sin elementos"); //si esta vacia dice que no tiene elementos
                        } else {
                            System.out.println("El Elemento Eliminado Es: " + LD.eliminarF()); //si tiene elementos, elimina el ultimo elemento
                            System.out.println("Lista de Inicio A Fin Con El Elemento Eliminado");
                            LD.MostarI(); //muestra la lista con ele elemento eliminado
                            System.out.println("Lista de Fin A Inicio Con El Elemento Eliminado");
                            LD.MostarF();
                        }
                    } else if (opcion == 3) {
                  if (LD.Vacia()) { //verifica si la lista esta vacia o no
                            System.out.println("Sin elementos"); //si esta vacia dice que no tiene elementos
                        } else {
                            System.out.println("Ingrese El Elemento A Eliminar"); //ingresa el elemento a eliminar
                            c = s.nextInt(); 
                            System.out.println("Elemento Eliminado");
                            LD.eliminarNodoUnico(c); //manda a llamar el proceso de eliminar un elemento en especifico
                            System.out.println("Lista de Inicio A Fin con El Elemento Eliminado");
                            LD.MostarI(); //muestra la lista con el elelemto eliminado
                            System.out.println("Lista de Fin A Inicio con El Elemento Eliminado");
                            LD.MostarF();
                        }

                    } else if (op > 3) {
                        System.out.println("Opcion no valida!!!"); //si agrega una opcion que no esta
                    }
                    break;
                case 4:
                    System.out.println("Hasta la proxima, :)"); //final del programa
                    System.exit(0);
                    break;//despedida cute xd 
                default:
                    System.out.println("\t!!!Opcion Incorrecta!!!");// por si el usuario  pone algo que no 
            }
        } while (op == op);
    }

}