/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listasdobles;

/**
 *
 * @author Esteban Lopez
 */
class NodoDoble {
    
    public int dato;
    NodoDoble siguiente,ante; //punteros
    
     public NodoDoble (int ele){ //si no hay datos
        this(ele, null, null); //si no hay datos elemento sus punteros apuntan a nulo
    }
    
    public NodoDoble (int ele, NodoDoble s, NodoDoble a) { // si hay datos ingresados
                                                                                      // recibe 3 parametros y recibe los punteros
        dato=ele;
        siguiente=s;
        ante=a;
        
    }
   
}
