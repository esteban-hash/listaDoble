/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listasdobles;

/**
 *
 * @author Esteban Lopez
 */
class ListaDoble {
    private NodoDoble inicio,fin; //creacion de dos punteros Tipo Nodo Doble
    public ListaDoble (){ //inicializa fin, inicio y nulo
        inicio=fin=null;
    }
    // os pa saber si esta vacia xD
    public boolean Vacia(){
        return inicio==null;
        
    }
    public  void Fin (int ele) { //ingresar datos al final
        if(!Vacia()){ //si la lista esta vacia
            fin=new NodoDoble(ele, null, fin); 
            fin.ante.siguiente=fin;
        }else{
            inicio =fin = new NodoDoble(ele);
            
        }
    }
        public  void Inicio (int ele) { //metodo para agredar datos al inicio
        if(!Vacia()){
            inicio=new NodoDoble(ele, inicio, null);
            inicio.siguiente.ante=inicio;
        }else{
            inicio =fin = new NodoDoble(ele);
            
        }
    }
        public void MostarI() { //Mostrar la lista desde el inicio a fin 
            if(!Vacia()){ //verifica si esta vacia
                String datos =""; //se crea una variable tipo string para poder mostrar los datos
                                        // de forma cute xD
                NodoDoble aux=inicio;
                while(aux!=null){
                    datos = datos + "[" + aux.dato + "]";
                    aux=aux.siguiente;
                }
                System.out.println(datos); //muestra los datos
            }
        }
        
         public void MostarF() { //Mostrar la lista desde el fin
            if(!Vacia()){
                String datos ="";
                NodoDoble aux=fin;
                while(aux!=null){
                    datos = datos + "[" + aux.dato + "]";
                    aux=aux.ante;
                }
                System.out.println(datos);
            }
        }
       public int eliminarI(){
           int ele=inicio.dato; //variable que contiene a inico de dato
           if (inicio==fin){ //compara si inicio es igual a fin
               inicio=fin=null; // si solo hay un elemtento apuntan a nulo a
               
           }else{ //sino 
               inicio=inicio.siguiente; //inicio apunta a inicio de siguiente 
               inicio.ante=null; //inicio apunta a anterior a nulo
           }
            return ele; //retorna el valor 
       }
       public int eliminarF(){
           int ele=fin.dato;
           if(inicio==fin){
               inicio=fin=null;
           }else{
               fin=fin.ante;
               fin.siguiente=null;
           }
           return ele;
       }
    public void eliminarNodoUnico(int el) { //metodo para eliminar un elemento especifico
        if (Vacia()) { // verifica si la lista esta vacia 
            System.out.println("Lista vacia"); //sino manda un mensaje que dice que la lista esta vacia
        } else if (fin == inicio) {
            if (el == inicio.dato) { //elemento es igual a inicio de dato
                fin = inicio = null; //inicio y fin apuntan a nulo
            } else {
                System.out.println("Error"); //sino manda un error
            }
        } else if (el == inicio.dato) { //elemento es igual a inicio de dato
            inicio = inicio.siguiente; //inicio es igual a inicio de siguiente
            inicio.ante = null;  // inicio de anterior es igual a nulo
        } else {
            NodoDoble temporal, anterior, siguiente; // se crean los 3 punteros temporales, siguiente y anterior 
            temporal = inicio;
            siguiente = inicio;
            anterior = inicio;
            while (siguiente != null && siguiente.dato != el) { //rrecorre la lista mientras siguiente sea diferente de nulo y siguiente de dato sea diferente de elemento
                // recorre los punteros hasta encontar un elemento
                temporal = temporal.siguiente; 
                siguiente = siguiente.siguiente; 
                anterior = anterior.siguiente; 
                
            }
            
            if (siguiente != null && siguiente != fin) { //si siguiente fue diferente de nulo si encontro el elemteno y siguiente diferente de fin
                siguiente.siguiente.ante = temporal.ante; // se apunta a siguiente de 
                anterior.ante.siguiente = temporal.siguiente; //se apunta a anterior de anterior de siguiente igual a temporal de siguiente
            } else {
                if (siguiente == fin) { // verifica si siguiente es igual a fin 
                    fin = fin.ante; //se mueve el fin a fin de anterior
                    fin.siguiente = null; 
                }
            }
        }
    }
}
    

